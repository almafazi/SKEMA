<?php
include '../koneksi.php';

if(
  isset($_POST['nim'])  &&
  isset($_POST['email'])
) {
  $nim = $_POST['nim'];
  $email = $_POST['email'];
  $nama = $_POST['nama'];
  $line = $_POST['idline'];
  $ttl = $_POST['ttl'];
  $jurusan = $_POST['jurusan'];
  $fakultas = $_POST['fakultas'];
  $motivasi = $_POST['motivasi'];
  $ukm = $_POST['ukm'];

}

$ambil = mysql_query("SELECT * FROM Mahasiswa WHERE nim = '$nim' OR email = '$email'");
$cek = mysql_num_rows($ambil);

if($cek == 0){
  mysql_query("INSERT INTO Mahasiswa (nim,email,nama,idline,ttl,jurusan,fakultas,motivasi,ukm)
   VALUES('$nim','$email','$nama','$line','$ttl','$jurusan', '$fakultas', '$motivasi', '$ukm')") or die(mysql_error($link));
  echo "
  <script> alert('Pendaftaran Berhasil, Mohon Tunggu Informasi Mahasiswa Yang Lolos Seleksi Setelah Jadwal Ditutup :)');
  window.history.back();
  </script>";
} else {
  echo "
  <script> alert('Error!, Data Sudah Terdaftar');
  window.history.back();
  </script>";
}


?>
