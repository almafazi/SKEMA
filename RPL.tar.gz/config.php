<?php
$host	= "localhost";
$user	= "root";
$pass	= "";
$name	= "SI";

mysql_connect("$host", "$user", "$pass");
mysql_select_db("$name");


?>
