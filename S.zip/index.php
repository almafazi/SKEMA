<?php
include 'func/header.php';
include 'init/koneksi.php';
?>
    <body data-brix_class="1482248775901">
    	<div class="container-fluid" data-brix_class="1482251079029">
         <div class="container">
             <div class="row" data-brix_class="1482260028977">
                 <div class="col-md-6"><img class="img-thumbnail img-responsive" src="assets/img/Selection_126.png" data-brix_class="1482250870894"></div>
                 <div class="col-md-6 text-center">
                     <ul class="nav nav-pills pull-right" data-brix_class="1482258431563">
                         <li class="active"><a href="index.php">Home</a></li>
                         <li class="dropdown">
                             <a class="dropdown-toggle" data-toggle="dropdown" href="#">Daftar UKM <span class="caret"></span></a>
                             <ul class="dropdown-menu" role="menu">
                                <li><p>&nbsp;&nbsp;&nbsp;Akademik</p></li>
                                 <li><a href="UKM/psc.php">PSC</a></li>
                                 <li><a href="#">INRO</a></li>
                                 <li><a href="#">Synaptic</a></li>
                                 <li><a href="UKM/invose.php">INVOSE</a></li>
                                 <li><a href="#">GAPOERA</a></li>
                                 <li><a href="#">MOTION-D</a></li>
                                 <li><a href="#">UCG</a></li>
                                 <li><p>&nbsp;&nbsp;&nbsp;Non Akademik</p></li>
                                 <li><a href="#">KOSMIK</a></li>
                                 <li><a href="#">GEMA</a></li>
                             </ul>
                         </li>
                     </ul>
                 </div>
             </div>
             <div class="row" data-brix_class="1482252480935">
               <?php include 'slider.php'; ?>
             </div>
             <div class="row" data-brix_class="1482252709179">
                 <div class="col-md-6">
                     <h2><b>Info :</b></h2>
                     <p>Penjadwalan kegiatan rutin UKM informatika telah dirilis pada hari Senin, 19 Desember 2016.</p>
                     <img src="assets/img/652aa3_1af77549eceb40578baafe03e71a7949~mv2.jpg" class="img-responsive">
                 </div>
                 <div class="col-md-6" data-brix_class="1482249322482">
                   <h3><b>Mendaftar UKM:</b></h3>
                     <form role="form" name="formulir" action="konfirmasi.php" method="POST" onSubmit="return validasi()">
                         <div class="form-group">
                             <label class="control-label" for="inputLabel1">Nama</label>
                             <input class="form-control" name="nama" id="inputLabel1" data-brix_class="1482261046653" placeholder="Masukkan Nama" type="text">
                         </div>
                         <div class="form-group">
                             <label class="control-label" for="inputLabel1">NIM</label>
                             <input class="form-control" name="NIM" id="inputLabel1" data-brix_class="1482261057756" placeholder="Masukkan NIM" type="text">
                         </div>
                         <div class="form-group">
                             <label class="control-label" for="inputLabel1">ID Line</label>
                             <div class="input-group">
                                 <span class="input-group-addon" data-brix_class="1482261715211">@</span>
                                 <input class="form-control" name="line" placeholder="ID Line" data-brix_class="1482261683399" type="text">
                             </div>
                         </div>
                         <div class="form-group">
                             <label>Jenis Kelamin :&nbsp;</label>
                             <label class="radio-inline">
                                 <input id="inlineRadio1" value="Laki-laki" name="jkel" type="radio">
                                 &nbsp;&nbsp;Laki-Laki
                             </label>
                             <label class="radio-inline">
                                 <input id="inlineRadio2" value="Perempuan" name="jkel" type="radio">
                                 &nbsp;&nbsp;Perempuan
                             </label>
                         </div>
                         <div class="form-group">
                             <label class="control-label" for="inputLabel1">Pilih UKM</label>
                             <select name="pilihukm" class="form-control" data-brix_class="1482261706273">
                               <optgroup label="AKADEMIK">
                                 <option value="psc">PSC</option>
                                 <option value="invose">INVOSE</option>
                                 <option value="inro">INRO</option>
                                 <option value="synaptic">SYNAPTIC</option>
                                 <option value="gapoera">GAPOERA</option>
                                 <option value="ucg">UCG</option>
                                 <option value="motion-d">MOTION-D</option>
                              <optgroup label="NON AKADEMIK">
                                <option value="kosmik">KOSMIK</option>
                                <option value="gema">GEMA</option>

                             </select>
                         </div>
                         <input type="submit" class="btn btn-default" value="daftar"/>
                     </form>
                 </div>
             </div>
             <div class="row">
                 <div class="col-md-6">
                     <strong data-brix_class="1482258731094">Bewara</strong>
                     <?php
                     $dataPerPage = 2;

                     if(isset($_GET['page'])){
                       $noPage = $_GET['page'];
                     }else{
                       $noPage = 1;
                     }

                     $offset = ($noPage - 1) * $dataPerPage;
                        $sql = mysql_query("SELECT * FROM tw_blog ORDER BY blog_id DESC LIMIT $offset, $dataPerPage");
                        while($data = mysql_fetch_assoc($sql)){
                      echo '
                     <article>
                       <blockquote>
                           <span style="color:#717070"> '.$data['blog_date'].' </span></br>
                           <a href="single.php?id='.$data['blog_id'].'" style="text-decoration:none"><strong>'.$data['blog_title'].'</strong></a>
                           <p>'.substr($data['blog_body'],0,150).'[..]</p>
                       </blockquote>
                     </article>';
                    }?>
                 </div>
                 <div class="col-md-6">
                     <h1>
                         Supported by:<br>
                     </h1>
                     <span data-brix_class="1482258916572">
                         Himpunan Mahasiswa Teknik Informatika<br>
                         Universitas Islam Indonesia<br>
                     </span>
                     <img class="img-circle pull-right img-responsive" src="assets/img/hmtf_logo.jpg" data-brix_class="1482341540080"><img class="img-circle pull-right img-responsive" src="assets/img/Logo-UII-Biru-BACKGROUND-TERANG.png" data-brix_class="1482341540080">
                 </div>
             </div>

             <script>
          function validasi(){
          var namaValid    = /^[a-zA-Z]+(([\'\,\.\- ][a-zA-Z ])?[a-zA-Z]*)*$/;
          var nama         = formulir.nama.value;
          var line       = formulir.line.value;
          var jkel      = formulir.jkel.value;
          var pesan = '';

          if (nama == '') {
              pesan = '- Nama tidak boleh kosong\n';
          }

          if (nama != '' && !nama.match(namaValid)) {
              pesan += '- nama tidak valid\n';
          }

          if (line == '') {
              pesan = '- Line tidak boleh kosong\n';
          }

          if (line != '' && !nama.match(namaValid)) {
              pesan += '- nama tidak valid\n';
          }

          if (jkel == '') {
              pesan += '- Jenis kelamin harus dipilih\n';
          }


          if (pesan != '') {
              alert('Maaf, ada kesalahan pengisian Formulir : \n'+pesan);
              return false;
          }
      return true
      }
  </script>
<?php include 'func/footer.php' ?>
