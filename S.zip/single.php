<?php
include 'config.php';
$id = abs((int)$_GET['id']);
$sql = mysql_query("SELECT * FROM tw_blog WHERE blog_id='$id'") or die(mysql_error());
if(mysql_num_rows($sql) == 0){
	echo 'Blank...!';
}else{
	$data = mysql_fetch_assoc($sql);
}
include 'func/header.php';
?>
    <body data-brix_class="1482248775901">
    	<div class="container-fluid" data-brix_class="1482251079029">
         <div class="container">
             <div class="row" data-brix_class="1482260028977">
                 <div class="col-md-6"><img class="img-thumbnail img-responsive" src="assets/img/Selection_126.png" data-brix_class="1482250870894"></div>
                 <div class="col-md-6 text-center">
                     <ul class="nav nav-pills pull-right" data-brix_class="1482258431563">
                         <li class="active"><a href="index.php">Home</a></li>
                         <li class="dropdown">
                             <a class="dropdown-toggle" data-toggle="dropdown" href="#">Daftar UKM <span class="caret"></span></a>
                             <ul class="dropdown-menu" role="menu">
                                <li><p>&nbsp;&nbsp;&nbsp;Akademik</p></li>
                                 <li><a href="UKM/psc.php">PSC</a></li>
                                 <li><a href="#">INRO</a></li>
                                 <li><a href="#">Synaptic</a></li>
                                 <li><a href="UKM/invose.php">INVOSE</a></li>
                                 <li><a href="#">GAPOERA</a></li>
                                 <li><a href="#">MOTION-D</a></li>
                                 <li><a href="#">UCG</a></li>
                                 <li><p>&nbsp;&nbsp;&nbsp;Non Akademik</p></li>
                                 <li><a href="#">KOSMIK</a></li>
                                 <li><a href="#">GEMA</a></li>
                             </ul>
                         </li>
                     </ul>
                 </div>
             </div>
             <div class="row" data-brix_class="1482252480935">
               <?php include 'slider.php'; ?>
             </div>

<body>
    	<div class="container-fluid">
         <div class="row" data-brix_class="1482388554894" style="width:70%">
             <article>
							 <em><b> Tanggal : <?= $data['blog_date'] ?> </b></em>
                 <h1><?= $data['blog_title'] ?></h1>
                 <p><?= $data['blog_body'] ?></p>
             </article>
         </div>
     </div>
