<div class="row" data-brix_class="1482259151323">
    <div class="col-md-6">
    </div>
    <div class="col-md-6">
        <footer class="pull-right" data-brix_class="1482261489230">
            <small data-brix_class="1482259314034">
                © 2016 by SispenKM Team.&nbsp;&nbsp;&nbsp; <br>
            </small>
            <img class="clearfix" src="assets/img/fb.png"><img src="assets/img/tw.png"><img src="assets/img/g+.png">
        </footer><br>
    </div>
</div>
</div>
</div>
</body></html>
