<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <script src='dist/sweetalert.min.js'></script>
    <link rel='stylesheet' type='text/css' href='dist/sweetalert.css'>
  </head>
</html>
<?php
session_start();
$host = "localhost";
$user = "root";
$pass = "";
$dbname ="SI";
$conn = mysql_connect($host,$user,$pass);
if($conn) {
//select database
$sele = mysql_select_db($dbname);
if(!$sele) {
echo mysql_error();
}
}
#***************** akhir koneksi ******************#
#jika ditekan tombol login
if(isset($_POST['submit'])) {
$username = $_POST['username'];
$password = $_POST['password'];
$password = md5($password);
$sql = mysql_query("SELECT * FROM Admin WHERE user='$username' &&
pass='$password'");
$num = mysql_num_rows($sql);
if($num==1) {
// login benar //
$_SESSION['user'] = $username;
?><script language="JavaScript">swal('Selamat!', 'Login Sukses', 'success'); setTimeout(function(){location.href='admin.php'} , 2000); </script><?
} else {
// jika login salah //
echo "Redirecting ... <script language='JavaScript'>swal('Error!', 'User Harus Sesuai', 'error'); setTimeout(function(){location.href='admin.php'} , 1000); </script>";
//include("login.php");

}
}
?>
