<?
session_start();
if (!isset($_SESSION['user'])){
header("Location:index.html");
}
else {
  $namaukm = $_SESSION['user'];
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="editor" content="brix.io">

        <title>Admin Panel</title>

        <!-- Bootstrap -->
        <link href="https://netdna.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet">
        <!-- Font Awesome -->
        <link href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" rel="stylesheet">


        <!-- User -->
        <link href="assets/css/style.css" rel="stylesheet">
        <link href="style.css" rel="stylesheet">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <!--[endif]---->

        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="https://netdna.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>

    </head>
    <body data-brix_class="1482327265484">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-success"><button class="close" aria-hidden="true" type="button" data-dismiss="alert">×</button><strong>Selamat Datang <?= $namaukm ?></strong></div>
                </div>
            </div>
        </div>
        <div class="row">
            <?php if ($namaukm == 'invose') { ?>
            <div class="col-md-4"><button onclick="window.open('tampil/invose.php')" type="button" class="btn btn-default pull-right" data-brix_class="1482327406668">Tampilkan Data Pendaftar</button></div>
            <?php } else if ($namaukm == 'psc') { ?>
              <div class="col-md-4"><button onclick="window.open('tampil/psc.php')" type="button" class="btn btn-default pull-right" data-brix_class="1482327406668">Tampilkan Data Pendaftar</button></div>
              <?php } ?>
            <div class="col-md-4"><button onclick="window.location.href='artikel/bewara.php'" type="button" class="btn btn-default" data-brix_class="1482327494460">Tambahkan Berita Populer </button></div>
            <div class="col-md-4"><button onclick="window.location.href='../logout.php'" type="button" class="btn btn-default pull-left" data-brix_class="1482327536284">Logout</button></div>
        </div></BR>
        <div class="row">
            <?php if ($namaukm == 'invose') { ?>
            <div class="col-md-4"><button onclick="window.open('tampil/invose.php')" type="button" class="btn btn-default pull-right" data-brix_class="1482327406668">Edit Informasi UKM</button></div>
            <?php } else if ($namaukm == 'psc') { ?>
              <div class="col-md-4"><button onclick="window.open('tampil/psc.php')" type="button" class="btn btn-default pull-right" data-brix_class="1482327406668">Edit Informasi UKM</button></div>
              <?php } ?>
              <div class="col-md-4"><button onclick="window.location.href='artikel/bewara.php'" type="button" class="btn btn-default" data-brix_class="1482327494460">Edit Info Utama </button></div>
        </div></BR>

    </body></html>
<?php } ?>
