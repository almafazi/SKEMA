<?php
include'config.php';
error_reporting(0);
session_start();
$nama = $_SESSION['user'];

if (!isset($nama)) {
	header('Location:../index.html');
} else {
?>


<div class="content-title">Tambahkan Berita Populer</div>
<div class="content-body">
    <p>
    <table width="100%" border="1" cellpadding="5" style="border-collapse:collapse">
    	<tr bgcolor="#CCC">
        	<th width="40">No.</th>
            <th width="100">Tgl. Tulis</th>
            <th>Judul Artikel</th>
            <th width="100">Aksi</th>
        </tr>
        <?php
		$sql = mysql_query("SELECT * FROM tw_blog ORDER BY blog_id DESC");
		if(mysql_num_rows($sql) != 0){
			$no = 1;
			while($data = mysql_fetch_assoc($sql)){
				echo '<tr>';
				echo '<td align="center">'.$no.'</td>';
				echo '<td>'.$data['blog_date'].'</td>';
				echo '<td>'.$data['blog_title'].'</td>';
				echo '<td align="center">';
					echo '<a href="bewara.php?aksi=edit&id='.$data['blog_id'].'">Edit</a> / ';
					echo '<a href="bewara.php?aksi=delete&id='.$data['blog_id'].'" onclick="return confirm(\'Anda yakin?\');">Delete</a>';
				echo '</td>';
				echo '</tr>';
				$no++;
			}
		}else{
			echo '<tr><td colspan="3">Tidak ada data.</td></tr>';
		}
		?>
    </table>
    </p>

    <?php

	if(!$_GET['aksi']){
		if($_POST['tambah-blog']){
			$date	= date("Y-m-d");
			$user	= $_SESSION['user'];
			$kat	= $_POST['kat'];
			$judul	= $_POST['judul'];
			$konten	= $_POST['konten'];

			if($judul && $konten){
				$in = mysql_query("INSERT INTO tw_blog VALUES(NULL, '$user', '$kat', '$date', '$judul', '$konten')");
				if($in){
					echo '<script language="javascript">alert("Artikel berhasil ditambahkan."); document.location="bewara.php";</script>';
				}else{
					echo '<div class="error">ERROR: Gagal menambahkan artikel.</div>';
				}
			}else{
				echo '<div class="error">ERROR: Masukkan judul dan konten artikel.</div>';
			}
		}

		echo '<form action="" method="post">';
		echo '<h3>Tambah Artikel</h3>';
    	echo '<p>Judul:<br /><input type="text" name="judul" /></p>';
		echo '<p>Konten Artikel:<br /><textarea name="konten" rows="8" cols="50"></textarea></p>';
        echo '<input type="submit" name="tambah-blog" value="Tambah" />';
    	echo '</form>';
	}

	//edit
	if($_GET['aksi'] == "edit"){
		$id = abs((int)$_GET['id']);
		$get = mysql_query("SELECT * FROM tw_blog WHERE blog_id='$id'");
		$dataGet = mysql_fetch_assoc($get);

		if($_POST['simpan-blog']){
			$kat	= $_POST['kat'];
			$judul	= $_POST['judul'];
			$konten	= $_POST['konten'];

			if($judul && $konten){
				$up = mysql_query("UPDATE tw_blog SET blog_cat_id='$kat', blog_title='$judul', blog_body='$konten' WHERE blog_id='$id'");
				if($up){
					echo '<script language="javascript">alert("Artikel berhasil disimpan."); document.location="bewara.php?aksi=edit&id='.$id.'";</script>';
				}else{
					echo '<div class="error">ERROR: Gagal menyimpan artikel.</div>';
				}
			}else{
				echo '<div class="error">ERROR: Masukkan judul dan konten artikel.</div>';
			}
		}

		echo '<form action="" method="post">';
		echo '<h3>Tambah Artikel</h3>';
    	echo '<p>Judul:<br /><input type="text" name="judul" value="'.$dataGet['blog_title'].'" /></p>';
		echo '<p>Konten Artikel:<br /><textarea name="konten" rows="8" cols="50">'.$dataGet['blog_body'].'</textarea></p>';
        echo '<input type="submit" name="simpan-blog" value="Simpan" />';
    	echo '</form>';
	}

	//delete
	if($_GET['aksi'] == "delete"){
		$id = abs((int)$_GET['id']);
		$cek = mysql_query("SELECT * FROM tw_blog WHERE blog_id='$id'");
		if(mysql_num_rows($cek) != 0){
			$del = mysql_query("DELETE FROM tw_blog WHERE blog_id='$id'");
			if($del){
				echo '<script language="javascript">alert("Data berhasil dihapus."); document.location="bewara.php";</script>';
			}else{
				echo '<script language="javascript">alert("Gagal menghapus data."); document.location="bewara.php";</script>';
			}
		}else{
			echo '<script language="javascript">alert("Data tidak ditemukan."); document.location="bewara.php";</script>';
		}
	}
}
	?>
</div>
