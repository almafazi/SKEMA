<?php
session_start();
$namaukm = $_SESSION['user'];
if (!isset($_SESSION['user']) || $namaukm != 'psc'){
header("Location:../index.html");
}
else { ?>
<!doctype html>
<html lang="en">
<head>
<title>Tampil Data UKM psc</title>
<meta content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" name="viewport"/>
<link href="css/bootstrap.css" rel="stylesheet">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Daftar Pendaftar UKM</h2>
  <p>UKM PSC</p>

<table id="mytable" class="table table-bordered">
    <thead>
      <th>No</th>
      <th>Name</th>
      <th>NIM</th>
      <th>Line</th>
      <th>Jenis Kelamin</th>
      <th>Tanggal Daftar</th>
    </thead>
<?php
  //menampilkan data mysqli
  include "koneksi.php";
  $no = 0;
  $modal=mysql_query("SELECT * FROM Mahasiswa WHERE UKM='psc'");
  while($r=mysql_fetch_array($modal)){
  $no++;

?>
  <tr>
      <td><?php echo $no; ?></td>
      <td><?php echo  $r['Nama']; ?></td>
      <td><?php echo  $r['NIM']; ?></td>
      <td><?php echo  $r['Idline']; ?></td>
      <td><?php echo  $r['jkel']; ?></td>
      <td><?php echo  $r['Tanggal Daftar']; ?></td>
  </tr>


<?php } ?>
</table>
</div>
</body>
</html>

<?php }?>
