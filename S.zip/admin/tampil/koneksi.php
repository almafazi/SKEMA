<?php
	$host="localhost";
	$user="root";
	$pass="";
	mysql_connect($host,$user,$pass) or die("Error Connect DB ".mysql_error());
	mysql_select_db("SI") or die("Database Tidak Ada. ".mysql_error());
?>
