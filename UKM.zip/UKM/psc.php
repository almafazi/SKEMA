<?php include "../func/header.php"; ?>

    <body>
    <style>
    [data-brix_class="1482337850764"]{
        margin-top: 0;
        margin-right: auto;
        margin-bottom: 0;
        margin-left: auto;
        width: 60%;
    }
    [data-brix_class="1482337831876"]{
        width: 60%;
        margin-top: 0;
        margin-right: auto;
        margin-bottom: 20px;
        margin-left: auto;
    }
    [data-brix_class="1482337737680"]{
        width: 60%;
        margin-top: 0;
        margin-right: auto;
        margin-left: auto;
        margin-bottom: 20px;
    }

    </style>

      <link href="../assets/css/style.css" rel="stylesheet">
    	<div class="container-fluid">
        <div class="container">
        <div class="row" data-brix_class="1482260028977">
            <div class="col-md-6"><img class="img-thumbnail img-responsive" src="../assets/img/Selection_126.png" data-brix_class="1482250870894"></div>
            <div class="col-md-6 text-center">
                <ul class="nav nav-pills pull-right" data-brix_class="1482258431563">
                    <li class="active"><a href="http://localhost:7777/S">Home</a></li>
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Daftar UKM <span class="caret"></span></a>
                        <ul class="dropdown-menu" role="menu">
                           <li><p>&nbsp;&nbsp;&nbsp;Akademik</p></li>
                            <li><a href="psc.php">PSC</a></li>
                            <li><a href="#">INRO</a></li>
                            <li><a href="#">Synaptic</a></li>
                            <li><a href="invose.php">INVOSE</a></li>
                            <li><a href="#">GAPOERA</a></li>
                            <li><a href="#">MOTION-D</a></li>
                            <li><a href="#">UCG</a></li>
                            <li><p>&nbsp;&nbsp;&nbsp;Non Akademik</p></li>
                            <li><a href="#">KOSMIK</a></li>
                            <li><a href="#">GEMA</a></li>

                        </ul>
                    </li>
                </ul>
            </div>
        </div>
        <div class="row" data-brix_class="1482252480935">
            <div class="col-md-12"><img src="../assets/img/banner-hp-ceas1.png" data-brix_class="1482249662529"></div>
        </div>
         <div class="row" data-brix_class="1482337737680">
             <div class="col-md-4">
                 <h1>
                     Programming<br>
                     Study Club(PSC)<br>
                 </h1>
                 <strong>Pembimbing : Hanson Prihantoro Putro</strong>
             </div>
             <div class="col-md-4"></div>
             <div class="col-md-4"><img src="../assets/img/652aa3_a19975ef9dab4b2d8dd0f6ec8c951e56~mv2_d_2613_1334_s_2.png"></div>
         </div>
         <div class="row" data-brix_class="1482337831876">
             <div class="col-md-4">
                 <p>PSC adalah sebuah UKM untuk wadah pembeajaran algoritma dan berbagai macam Bahasa pemrograman</p>
             </div>
             <div class="col-md-4"></div>
             <div class="col-md-4">
                 <strong>Kegiatan Rutin</strong>
                 <p>Setiap selasa jam 08.00-15.00 di Lap terpadu Lt. 3 Gd. FIAI </p>
             </div>
         </div>
         <div class="row" data-brix_class="1482337850764">
             <div class="col-md-4">
                 <strong>Struktur Organisasi</strong>
                 <p>
                     Ketua          : Dicky Puja Pratama<br>
                     Sekretaris   : Retno Ayuningtias<br>
                     Bendahara  : Nadila Putri<br>
                 </p>
             </div>
             <div class="col-md-4"></div>
             <div class="col-md-4">
                 <strong>Prestasi</strong>
                 <p>
                     1. juara 3 Techporia 2016<br>
                     2. juara 3 Techporia 2015<br>
                 </p>
             </div>
         </div>
         <div class="row" data-brix_class="1482337850764">
             <div class="col-md-12">
                 <a href="#" ><h4>Lihat Daftar Foto</h4></a>
             </div>
         </div>
         <div class="row" data-brix_class="1482259151323">
             <div class="col-md-6">
                 <h1 data-brix_class="1482259214406">SisPenKM Team</h1>
             </div>
             <div class="col-md-6">
                 <footer class="pull-right" data-brix_class="1482261489230">
                     <small data-brix_class="1482259314034">
                         © 2016 by SispenKM Team.&nbsp;&nbsp;&nbsp; <br>
                     </small>
                     <img class="clearfix" src="../assets/img/fb.png"><img src="../assets/img/tw.png"><img src="../assets/img/g+.png">
                 </footer>
             </div>
         </div>
         </div>
         </div>
         </body></html>
